import React from "react";

const Theme = () => {
  return (
    <div className="page">
      <div className="container">
        <h1 className="title">Theme</h1>
      </div>
    </div>
  );
};

export default Theme;
